package seleinuimwddemo;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HotelLoginTest {

	static WebDriver driver;

	@BeforeClass
	public static void browser() {

		System.setProperty("webdriver.chrome.driver", "D:\\STS_Programs\\chromedriver.exe");
		// stem.setProperty("webdriver.chrome.driver","D:\\STS_Programs\\chromedriver.exe");

		driver = new ChromeDriver();
		// driver.get("D:\\STS_Programs\\App\\hotelbooking.html");
		driver.get("file:///D:/STS_Programs/App/hotelbooking.html");
	}

	@Test
	public void test() {

		WebElement firstname = driver.findElement(By.name("txtFN"));
		firstname.sendKeys("capgemini");

		WebElement lastname = driver.findElement(By.name("txtLN"));
		lastname.sendKeys("capgemini");

		WebElement email = driver.findElement(By.name("Email"));
		email.sendKeys("kkranthi@gmail.com");

		WebElement phone = driver.findElement(By.name("Phone"));
		phone.sendKeys("9090909090");

		WebElement city = driver.findElement(By.name("city"));
		//city.sendKeys("chennai");
		Select c=new Select(city);
		c.selectByIndex(3);
		
		
		
		WebElement state = driver.findElement(By.name("state"));
		//state.sendKeys("Tamilnadu");
		Select s=new Select(state);
		s.selectByIndex(4);
		
		
		WebElement persons= driver.findElement(By.name("persons"));
		//persons.sendKeys("10");
		Select p=new Select(persons);
		p.selectByIndex(5);
		

		 WebElement cardholder=driver.findElement(By.id("txtCardholderName"));
		 cardholder.sendKeys("chanu");
			

			WebElement debit = driver.findElement(By.name("debit"));
			debit.sendKeys("13782367846");
			

			WebElement cvv= driver.findElement(By.name("cvv"));
			cvv.sendKeys("377");
			

			WebElement month= driver.findElement(By.name("month"));
			month.sendKeys("Jan");
			

			WebElement year= driver.findElement(By.name("year"));
			year.sendKeys("2019");
			

			
			driver.findElement(By.xpath("//textarea[@rows='5']")).sendKeys("capgemini-chennai");
			
			
			
			WebElement button=driver.findElement(By.className("btn"));
		 
	}

	/*
	  @AfterClass
	  public void closeDriver() { WebDriver driver=null;
	  driver.close(); }*/
	 

}
