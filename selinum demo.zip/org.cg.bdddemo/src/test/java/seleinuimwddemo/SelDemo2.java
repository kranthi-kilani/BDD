package seleinuimwddemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SelDemo2 {
	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","D:\\STS_Programs\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		
		driver.navigate().to("file:///D:/STS_Programs/App/hotelbooking.html");
		System.out.println(driver.getTitle());
		System.out.println("-----------------------");
		System.out.println(driver.getCurrentUrl());
		System.out.println("-----------------------");
		System.out.println(driver.getPageSource());
		
	/*	driver.navigate().to("file:///D:/STS_Programs/App/login.html");
		System.out.println(driver.getTitle());
		
	
		 WebElement username=driver.findElement(By.name("userName"));
			username.sendKeys("capgemini");
			
			
			driver.navigate().forward();
			driver.navigate().refresh();
			 WebElement pass=driver.findElement(By.name("userPwd"));
				pass.clear();
				pass.sendKeys("capgemini");
				driver.navigate().back();
		
				
				WebElement button=driver.findElement(By.className("btn"));
		
		
	*/
		
	}
	
	
	
	

}
