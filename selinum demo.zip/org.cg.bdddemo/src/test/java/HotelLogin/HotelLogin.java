package HotelLogin;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelLogin {

@Given("^User is on login page\\.$")
public void user_is_on_login_page(){
    // Write code here that turns the phrase above into concrete actions
 
}

@Then("^check the heading of the page$")
public void check_the_heading_of_the_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions

}

@Given("^User is on login page$")
public void user_is_on_login_page11() {
    // Write code here that turns the phrase above into concrete actions
   
}

@Then("^navigate to hotelBooking$")
public void navigate_to_hotelBooking()  {
    // Write code here that turns the phrase above into concrete actions
 
}


@Given("^User is on login page to login$")
public void user_is_on_login_page_to_login() {
  
}

@When("^user doesnot enter either username or password$")
public void user_doesnot_enter_either_username_or_password()  {
  
}

@When("^clicks the Login Button$")
public void clicks_the_Login_Button() {
    // Write code here that turns the phrase above into concrete actions
  
}

@Then("^display appropriate message$")
public void display_appropriate_message()  {
  
}

@Given("^user is on login page$")
public void user_is_on_login_page1()  {
    // Write code here that turns the phrase above into concrete actions
  
}

@When("^user enters incorrect username or passsword$")
public void user_enters_incorrect_username_or_passsword()  {
    // Write code here that turns the phrase above into concrete actions
    
}

@Then("^display login failed message$")
public void display_login_failed_message()  {
    // Write code here that turns the phrase above into concrete actions
   
}


}
